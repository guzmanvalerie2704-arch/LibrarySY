<?php
require __DIR__ . '/config.php';
require_post();
$_SESSION = [];
session_destroy();
redirect('index.php');
