<?php
require __DIR__ . '/config.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    if (($_POST['next'] ?? '') !== ($_POST['confirm'] ?? '')) {
        flash('error', 'The two new passwords don’t match.');
    } else {
        $r = api_post('/users/' . (int)$_SESSION['userId'] . '/password', [
            'current' => $_POST['current'] ?? '',
            'next' => $_POST['next'] ?? '',
        ]);
        $r['ok'] ? flash('ok', 'Password changed.') : flash('error', $r['error']);
    }
    redirect('profile.php');
}

$title = 'My account';
$nav = 'profile';
require __DIR__ . '/includes/header.php';
?>
<section class="panel form-panel">
  <p><strong><?= h($_SESSION['user']) ?></strong><br>
    <span class="muted">Username: <?= h($_SESSION['username']) ?> · <?= is_admin() ? 'Librarian' : 'Student' ?></span></p>
</section>
<section class="panel form-panel spaced">
  <h2>Change password</h2>
  <form method="post" class="stack">
    <?= csrf_field() ?>
    <label>Current password
      <input name="current" type="password" required autocomplete="current-password">
    </label>
    <div class="row">
      <label>New password <span class="muted small">(6+ characters)</span>
        <input name="next" type="password" required minlength="6" autocomplete="new-password">
      </label>
      <label>Confirm new password
        <input name="confirm" type="password" required minlength="6" autocomplete="new-password">
      </label>
    </div>
    <div class="buttons"><button class="btn primary" type="submit">Change password</button></div>
  </form>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
