<?php
require __DIR__ . '/config.php';
require_admin();

$stats = api_get('/stats');
$loansRes = api_get('/loans', ['status' => 'active']);
$error = $stats['error'] ?: $loansRes['error'];
$s = $stats['data'] ?? [];
$loans = $loansRes['data']['loans'] ?? [];
usort($loans, function ($a, $b) { return strcmp($a['due'], $b['due']); }); // soonest due first

$title = 'Dashboard';
$nav = 'dashboard';
$headActions = '<a class="btn primary" href="issue.php">Issue a book</a>';
require __DIR__ . '/includes/header.php';
show_error($error);
?>
<?php if ($s): ?>
<section class="ledger" aria-label="Library at a glance">
  <div><b><?= (int)$s['titles'] ?></b><span>titles, <?= (int)$s['copies'] ?> copies</span></div>
  <div><b><?= (int)$s['available'] ?></b><span>copies on the shelf</span></div>
  <div><b><?= (int)$s['activeLoans'] ?></b><span>books out on loan</span></div>
  <div class="<?= $s['overdueLoans'] > 0 ? 'alert' : '' ?>"><b><?= (int)$s['overdueLoans'] ?></b><span>overdue</span></div>
  <div><b><?= h(money($s['finesAccruing'])) ?></b><span>fines owed right now</span></div>
  <div><b><?= (int)$s['members'] ?></b><span>members</span></div>
</section>
<?php if ($s['pendingRequests'] > 0): ?>
  <div class="notice good"><?= (int)$s['pendingRequests'] ?> borrow request<?= $s['pendingRequests'] == 1 ? '' : 's' ?> waiting for you.
    <a href="requests.php">Review requests</a></div>
<?php endif; ?>
<?php endif; ?>

<section class="panel">
  <div class="panel-head">
    <h2>On loan, soonest due first</h2>
    <a href="loans.php">All loans</a>
  </div>
  <?php if (!$loans): ?>
    <p class="empty">Nothing is out on loan. <a href="issue.php">Issue the first book.</a></p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Book</th><th>Member</th><th>Status</th><th class="num">Fine so far</th></tr></thead>
      <tbody>
      <?php foreach (array_slice($loans, 0, 8) as $l): ?>
        <tr>
          <td><?= h($l['bookTitle']) ?></td>
          <td><a href="loans.php?member=<?= (int)$l['memberId'] ?>"><?= h($l['memberName']) ?></a></td>
          <td><?= loan_stamp($l) ?></td>
          <td class="num"><?= $l['fine'] > 0 ? h(money($l['fine'])) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
