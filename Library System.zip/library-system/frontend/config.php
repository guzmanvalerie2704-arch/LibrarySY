<?php
/**
 * Front-end settings. Change these to suit your library.
 */
session_start();

// Where the Java backend is listening (see backend/run.sh).
define('API_BASE', getenv('LIBRARY_API') ?: 'http://127.0.0.1:8080/api');

define('APP_NAME', 'STI Library'); // name of the library, shown in the header and page titles
define('CURRENCY', '₱');   // symbol shown before fine amounts

require_once __DIR__ . '/includes/lib.php';
