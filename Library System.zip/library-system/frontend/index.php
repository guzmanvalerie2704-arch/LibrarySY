<?php
require __DIR__ . '/config.php';

if (!empty($_SESSION['user'])) {
    redirect(home_for_role());
}

$title = 'Welcome';
$bare = true;
require __DIR__ . '/includes/header.php';
?>
<section class="landing">
  <div class="landing-intro">
    <svg viewBox="0 0 220 120" width="220" height="120" aria-hidden="true">
      <rect x="6"   y="30" width="22" height="90" rx="2" fill="#7FB8A4"/>
      <rect x="32"  y="10" width="22" height="110" rx="2" fill="#E9E4D4"/>
      <rect x="58"  y="40" width="22" height="80" rx="2" fill="#C9694F"/>
      <rect x="84"  y="20" width="22" height="100" rx="2" fill="#E3B95B"/>
      <rect x="110" y="34" width="22" height="86" rx="2" fill="#7FB8A4"/>
      <rect x="136" y="4"  width="22" height="116" rx="2" fill="#E9E4D4"/>
      <rect x="162" y="26" width="22" height="94" rx="2" fill="#C9694F"/>
      <rect x="188" y="44" width="22" height="76" rx="2" fill="#E3B95B"/>
      <rect x="0" y="118" width="220" height="2" fill="#E9E4D4"/>
    </svg>
    <h1><?= h('STI Library'); ?></h1>
    <p><h2>Search the catalog, borrow and return books, and keep track of due dates and fines, all in one place.</h2></p>
  </div>

    <div class="landing-choices">
    <p class="who">Who is signing in?</p>

    <a class="choice student" href="login.php?as=student">
      <span class="icon" aria-hidden="true">
        <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
          <path d="M32 12 4 26l28 14 28-14z"/>
          <path d="M16 34v12c0 4 7 8 16 8s16-4 16-8V34"/>
          <path d="M60 26v16"/>
          <circle cx="60" cy="44" r="2"/>
        </svg>
      </span>
      <strong>I’m a student</strong>
      <span>Find books, send borrow requests and see what’s due.</span>
      <em>Sign in or create an account</em>
    </a>

    <a class="choice librarian" href="login.php?as=librarian">
      <span class="icon" aria-hidden="true">
        <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
          <path d="M32 16c-6-4-15-5-24-4v34c9-1 18 0 24 4 6-4 15-5 24-4V12c-9-1-18 0-24 4z"/>
          <path d="M32 16v34"/>
          <path d="M14 22c4 0 8 .5 12 2M14 30c4 0 8 .5 12 2M38 24c4-1.500 8-2 12-2M38 32c4-1.500 8-2 12-2"/>
        </svg>
      </span>
      <strong>I’m a librarian</strong>
      <span>Manage books and members, approve requests and handle returns.</span>
      <em>Sign in with your library account</em>
    </a>
  </div>
<?php require __DIR__ . '/includes/footer.php'; ?>
