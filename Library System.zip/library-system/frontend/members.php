<?php
require __DIR__ . '/config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $r = api_post('/members/' . (int)($_POST['id'] ?? 0) . '/delete');
    $r['ok'] ? flash('ok', 'Member deleted.') : flash('error', $r['error']);
    redirect('members.php');
}

$q = trim($_GET['q'] ?? '');
$res = api_get('/members', ['q' => $q]);
$members = $res['data']['members'] ?? [];

$title = 'Members';
$nav = 'members';
$headActions = '<a class="btn primary" href="member_form.php">Add a member</a>';
require __DIR__ . '/includes/header.php';
show_error($res['error']);
?>
<form class="filters" method="get">
  <label class="grow">Search
    <input type="search" name="q" value="<?= h($q) ?>" placeholder="Name, email or phone">
  </label>
  <button class="btn" type="submit">Search</button>
</form>

<section class="panel">
  <?php if (!$members): ?>
    <p class="empty"><?= $q ? 'No members match that search.' : 'No members yet.' ?> <a href="member_form.php">Add a member</a></p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Name</th><th>Contact</th><th>Joined</th><th>Books out</th><th>Status</th><th class="actions">Actions</th></tr></thead>
      <tbody>
      <?php foreach ($members as $m): ?>
        <tr>
          <td><strong><?= h($m['name']) ?></strong></td>
          <td><?= h($m['email'] ?: '—') ?><br><span class="muted"><?= h($m['phone'] ?: '') ?></span></td>
          <td><?= h(fmt_date($m['joined'])) ?></td>
          <td><?= (int)$m['activeLoans'] ?></td>
          <td><span class="tag <?= $m['active'] ? 'on' : 'off' ?>"><?= $m['active'] ? 'Active' : 'Inactive' ?></span></td>
          <td class="actions">
            <?php if ($m['active']): ?><a href="issue.php?member=<?= (int)$m['id'] ?>">Issue</a><?php endif; ?>
            <a href="member_form.php?id=<?= (int)$m['id'] ?>">Edit</a>
            <a href="loans.php?member=<?= (int)$m['id'] ?>">History</a>
            <form method="post" onsubmit="return confirm('Delete <?= h(addslashes($m['name'])) ?>? This can’t be undone.');">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
              <button type="submit" class="link danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
