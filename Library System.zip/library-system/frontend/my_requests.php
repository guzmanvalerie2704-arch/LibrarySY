<?php
require __DIR__ . '/config.php';
require_student();
$mid = (int)$_SESSION['memberId'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $r = api_post('/reservations/' . (int)($_POST['id'] ?? 0) . '/cancel', ['memberId' => $mid]);
    $r['ok'] ? flash('ok', 'Request cancelled.') : flash('error', $r['error']);
    redirect('my_requests.php');
}

$res = api_get('/reservations', ['status' => 'all', 'member' => $mid]);
$requests = $res['data']['reservations'] ?? [];

$title = 'My requests';
$nav = 'myrequests';
$headActions = '<a class="btn primary" href="catalog.php">Find a book</a>';
require __DIR__ . '/includes/header.php';
show_error($res['error']);
?>
<section class="panel">
  <?php if (!$requests): ?>
    <p class="empty">You haven’t requested any books yet. <a href="catalog.php">Find a book</a></p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Book</th><th>Requested</th><th>Status</th><th>Note</th><th class="actions">Action</th></tr></thead>
      <tbody>
      <?php foreach ($requests as $r): ?>
        <tr>
          <td><?= h($r['bookTitle']) ?></td>
          <td><?= h(fmt_date($r['requested'])) ?></td>
          <td><?= request_tag($r) ?></td>
          <td class="muted"><?= h($r['note'] ?: ($r['status'] === 'approved' ? 'Pick it up at the desk.' : '')) ?></td>
          <td class="actions">
            <?php if ($r['status'] === 'pending'): ?>
            <form method="post">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button type="submit" class="link danger">Cancel</button>
            </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
