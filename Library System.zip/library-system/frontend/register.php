<?php
require __DIR__ . '/config.php';

if (!empty($_SESSION['user'])) {
    redirect(home_for_role());
}

$error = null;
$f = ['name' => '', 'email' => '', 'phone' => '', 'username' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    foreach ($f as $k => $_) {
        $f[$k] = trim($_POST[$k] ?? '');
    }
    $password = $_POST['password'] ?? '';
    if ($password !== ($_POST['confirm'] ?? '')) {
        $error = 'The two passwords don’t match.';
    } else {
        $r = api_post('/register', $f + ['password' => $password]);
        if ($r['ok']) {
            start_session_for($r['data']);
            flash('ok', 'Welcome, ' . $r['data']['name'] . '! Your account is ready. Find a book to request.');
            redirect('home.php');
        }
        $error = $r['error'];
    }
}

$title = 'Create account';
$bare = true;
require __DIR__ . '/includes/header.php';
?>
<section class="auth-card wide">
  <h1>Create a student account</h1>
  <p class="muted">Borrow books from <?= h(APP_NAME) ?>. Use the email the library has on file if you’re already a member.</p>
  <?php show_error($error); ?>
  <form method="post" class="stack">
    <?= csrf_field() ?>
    <label>Full name
      <input name="name" required maxlength="120" value="<?= h($f['name']) ?>" autofocus>
    </label>
    <div class="row">
      <label>Email
        <input name="email" type="email" required maxlength="120" value="<?= h($f['email']) ?>">
      </label>
      <label>Phone <span class="muted small">(optional)</span>
        <input name="phone" maxlength="30" value="<?= h($f['phone']) ?>">
      </label>
    </div>
    <label>Username <span class="muted small">(letters, numbers, dots, underscores)</span>
      <input name="username" required minlength="3" maxlength="30" pattern="[A-Za-z0-9_.]+" autocomplete="username" value="<?= h($f['username']) ?>">
    </label>
    <div class="row">
      <label>Password <span class="muted small">(6+ characters)</span>
        <input name="password" type="password" required minlength="6" autocomplete="new-password">
      </label>
      <label>Confirm password
        <input name="confirm" type="password" required minlength="6" autocomplete="new-password">
      </label>
    </div>
    <button class="btn primary" type="submit">Create account</button>
  </form>
  <p class="alt">Already have an account? <a href="login.php?as=student">Sign in</a> · <a href="index.php">Back to start</a></p>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
