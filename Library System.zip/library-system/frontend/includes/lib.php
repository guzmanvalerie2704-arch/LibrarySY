<?php
/** Shared helpers: talking to the Java API, escaping, flash messages, CSRF, small widgets. */

// ---------- Java API ----------

/** Calls the Java backend. Returns ['ok' => bool, 'data' => array|null, 'error' => string|null]. */
function api_call(string $method, string $path, array $params = []): array
{
    $url = API_BASE . $path;
    $headers = "Accept: application/json\r\n";
    $http = ['method' => $method, 'ignore_errors' => true, 'timeout' => 10];

    if ($method === 'GET') {
        if ($params) {
            $url .= '?' . http_build_query($params);
        }
    } else {
        $headers .= "Content-Type: application/x-www-form-urlencoded\r\n";
        $http['content'] = http_build_query($params);
    }
    $http['header'] = $headers;

    $raw = @file_get_contents($url, false, stream_context_create(['http' => $http]));
    if ($raw === false) {
        return ['ok' => false, 'data' => null,
            'error' => 'Can’t reach the Java backend at ' . API_BASE . '. Start it first (see README.md).'];
    }

    $responseHeaders = function_exists('http_get_last_response_headers')
        ? (http_get_last_response_headers() ?: [])
        : ($http_response_header ?? []);
    $status = 0;
    if (!empty($responseHeaders[0]) && preg_match('#HTTP/\S+\s+(\d{3})#', $responseHeaders[0], $m)) {
        $status = (int)$m[1];
    }

    $data = json_decode($raw, true);
    if ($status >= 400 || !is_array($data)) {
        $msg = (is_array($data) && isset($data['error'])) ? $data['error'] : 'The backend sent an unexpected response.';
        return ['ok' => false, 'data' => null, 'error' => $msg];
    }
    return ['ok' => true, 'data' => $data, 'error' => null];
}

function api_get(string $path, array $params = []): array
{
    return api_call('GET', $path, $params);
}

function api_post(string $path, array $params = []): array
{
    return api_call('POST', $path, $params);
}

// ---------- output ----------

function h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function money($amount): string
{
    return CURRENCY . number_format((float)$amount, 2);
}

function fmt_date(?string $date): string
{
    return $date ? date('M j, Y', strtotime($date)) : '—';
}

function selected($a, $b): string
{
    return (string)$a === (string)$b ? ' selected' : '';
}

/** A row of small squares showing how many copies are on the shelf. */
function pips(int $available, int $total): string
{
    $label = $available . ' of ' . $total . ' on the shelf';
    if ($total > 10) {
        return '<span class="pips-text" title="' . h($label) . '">' . $available . '/' . $total . '</span>';
    }
    $out = '<span class="pips" role="img" aria-label="' . h($label) . '" title="' . h($label) . '">';
    for ($i = 0; $i < $total; $i++) {
        $out .= '<i class="' . ($i < $available ? 'on' : 'off') . '"></i>';
    }
    return $out . '</span>';
}

/** The date-stamp style badge used for loan status. */
function loan_stamp(array $loan): string
{
    if (!$loan['active']) {
        return '<span class="stamp done">Returned ' . h(fmt_date($loan['returned'])) . '</span>';
    }
    if ($loan['overdue']) {
        $d = (int)$loan['overdueDays'];
        return '<span class="stamp late">' . $d . ' day' . ($d === 1 ? '' : 's') . ' overdue</span>';
    }
    $days = (int)floor((strtotime($loan['due']) - strtotime(date('Y-m-d'))) / 86400);
    if ($days <= 3) {
        return '<span class="stamp soon">' . ($days === 0 ? 'Due today' : 'Due in ' . $days . ' day' . ($days === 1 ? '' : 's')) . '</span>';
    }
    return '<span class="stamp ok">Due ' . h(fmt_date($loan['due'])) . '</span>';
}

function show_error(?string $error): void
{
    if ($error) {
        echo '<div class="notice bad" role="alert">' . h($error) . '</div>';
    }
}

// ---------- navigation, flash, auth, CSRF ----------

function redirect(string $to): void
{
    header('Location: ' . $to);
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function take_flashes(): array
{
    $all = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $all;
}

function require_login(): void
{
    if (empty($_SESSION['user'])) {
        redirect('index.php');
    }
}

function is_admin(): bool
{
    return ($_SESSION['role'] ?? '') === 'admin';
}

function home_for_role(): string
{
    return is_admin() ? 'dashboard.php' : 'home.php';
}

/** Librarian-only pages. Students are sent to their own home page. */
function require_admin(): void
{
    require_login();
    if (!is_admin()) {
        flash('error', 'That page is for librarians only.');
        redirect('home.php');
    }
}

/** Student-only pages. Librarians are sent to the dashboard. */
function require_student(): void
{
    require_login();
    if (is_admin()) {
        redirect('dashboard.php');
    }
}

/** Stores the signed-in account (as returned by /login or /register) in the session. */
function start_session_for(array $account): void
{
    session_regenerate_id(true);
    $_SESSION['user'] = $account['name'];
    $_SESSION['username'] = $account['username'];
    $_SESSION['userId'] = (int)$account['id'];
    $_SESSION['role'] = $account['role'];
    $_SESSION['memberId'] = (int)$account['memberId'];
}

/** Status label for a borrow request. */
function request_tag(array $r): string
{
    $map = [
        'pending'   => ['wait', 'Waiting for the librarian'],
        'approved'  => ['on', 'Approved'],
        'rejected'  => ['bad', 'Declined'],
        'cancelled' => ['off', 'Cancelled'],
    ];
    $t = $map[$r['status']] ?? ['off', $r['status']];
    return '<span class="tag ' . $t[0] . '">' . h($t[1]) . '</span>';
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">';
}

/** Stops the request unless it is a POST carrying the session's CSRF token. */
function require_post(): void
{
    $ok = $_SERVER['REQUEST_METHOD'] === 'POST'
        && isset($_POST['csrf'])
        && hash_equals(csrf_token(), (string)$_POST['csrf']);
    if (!$ok) {
        http_response_code(400);
        exit('Bad request. Go back, reload the page and try again.');
    }
}
