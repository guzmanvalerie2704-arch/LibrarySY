<?php $bare = $bare ?? false; ?>
<?php if ($bare): ?>
</main>
<?php else: ?>
  </main>
</div>
<?php endif; ?>
</body>
</html>
