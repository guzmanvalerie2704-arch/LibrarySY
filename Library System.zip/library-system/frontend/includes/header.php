<?php
/** Expects: $title (string), $nav (string key), optional $headActions (trusted HTML), optional $bare (bool). */
$nav = $nav ?? '';
$bare = $bare ?? false;
if (is_admin()) {
    $items = [
        'dashboard' => ['dashboard.php', 'Dashboard'],
        'books'     => ['books.php', 'Books'],
        'members'   => ['members.php', 'Members'],
        'requests'  => ['requests.php', 'Requests'],
        'issue'     => ['issue.php', 'Issue a book'],
        'loans'     => ['loans.php', 'Loans'],
        'profile'   => ['profile.php', 'My account'],
    ];
} else {
    $items = [
        'home'      => ['home.php', 'My books'],
        'catalog'   => ['catalog.php', 'Find a book'],
        'myrequests'=> ['my_requests.php', 'My requests'],
        'profile'   => ['profile.php', 'My account'],
    ];
}
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= h($title) ?> · <?= h(APP_NAME) ?></title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="<?= $bare ? 'bare' : '' ?>">
<?php if ($bare): ?>
<main class="auth">
<?php else: ?>
<div class="shell">
  <aside class="side">
    <a class="brand" href="<?= home_for_role() ?>">
      <svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true">
        <rect x="4"  y="10" width="6" height="26" rx="1" fill="#7FB8A4"/>
        <rect x="12" y="4"  width="6" height="32" rx="1" fill="#E9E4D4"/>
        <rect x="20" y="13" width="6" height="23" rx="1" fill="#C9694F"/>
        <rect x="28" y="7"  width="6" height="29" rx="1" fill="#E3B95B"/>
      </svg>
      <span><?= h(APP_NAME) ?></span>
    </a>
    <nav aria-label="Main">
      <?php foreach ($items as $key => $item): ?>
        <a href="<?= $item[0] ?>"<?= $key === $nav ? ' class="current" aria-current="page"' : '' ?>><?= h($item[1]) ?></a>
      <?php endforeach; ?>
    </nav>
    <form class="signout" method="post" action="logout.php">
      <?= csrf_field() ?>
      <span><?= h($_SESSION['user'] ?? '') ?> (<?= is_admin() ? 'librarian' : 'student' ?>)</span>
      <button type="submit" class="link">Sign out</button>
    </form>
  </aside>
  <main class="main">
    <header class="page-head">
      <h1><?= h($title) ?></h1>
      <?php if (!empty($headActions)) echo '<div class="head-actions">' . $headActions . '</div>'; ?>
    </header>
    <?php foreach (take_flashes() as $f): ?>
      <div class="notice <?= $f['type'] === 'error' ? 'bad' : 'good' ?>" role="<?= $f['type'] === 'error' ? 'alert' : 'status' ?>"><?= h($f['message']) ?></div>
    <?php endforeach; ?>
<?php endif; ?>
