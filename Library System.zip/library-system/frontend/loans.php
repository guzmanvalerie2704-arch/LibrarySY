<?php
require __DIR__ . '/config.php';
require_admin();

$status = $_GET['status'] ?? 'active';
if (!in_array($status, ['active', 'overdue', 'returned', 'all'], true)) {
    $status = 'active';
}
$memberId = (int)($_GET['member'] ?? 0);
$bookId = (int)($_GET['book'] ?? 0);

// Return a book (POST from the table below).
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $r = api_post('/loans/return', ['loanId' => (int)($_POST['loanId'] ?? 0)]);
    if ($r['ok']) {
        $fine = (float)$r['data']['fine'];
        flash('ok', $fine > 0
            ? 'Book returned. It was ' . (int)$r['data']['overdueDays'] . ' day(s) late, so the fine is ' . money($fine) . '.'
            : 'Book returned on time. No fine.');
    } else {
        flash('error', $r['error']);
    }
    redirect('loans.php?' . http_build_query(array_filter([
        'status' => $status, 'member' => $memberId ?: null, 'book' => $bookId ?: null,
    ])));
}

$res = api_get('/loans', ['status' => $status, 'member' => $memberId ?: '', 'book' => $bookId ?: '']);
$loans = $res['data']['loans'] ?? [];

$tabs = ['active' => 'On loan', 'overdue' => 'Overdue', 'returned' => 'Returned', 'all' => 'All'];
$keep = array_filter(['member' => $memberId ?: null, 'book' => $bookId ?: null]);

$title = 'Loans';
$nav = 'loans';
$headActions = '<a class="btn primary" href="issue.php">Issue a book</a>';
require __DIR__ . '/includes/header.php';
show_error($res['error']);
?>
<nav class="tabs" aria-label="Loan status">
  <?php foreach ($tabs as $key => $label): ?>
    <a href="loans.php?<?= h(http_build_query(['status' => $key] + $keep)) ?>"<?= $key === $status ? ' class="current" aria-current="page"' : '' ?>><?= h($label) ?></a>
  <?php endforeach; ?>
  <?php if ($keep): ?><a class="clear" href="loans.php?status=<?= h($status) ?>">Clear member/book filter</a><?php endif; ?>
</nav>

<section class="panel">
  <?php if (!$loans): ?>
    <p class="empty">No loans to show here.</p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Book</th><th>Member</th><th>Issued</th><th>Status</th><th class="num">Fine</th><th class="actions">Action</th></tr></thead>
      <tbody>
      <?php foreach ($loans as $l): ?>
        <tr>
          <td><?= h($l['bookTitle']) ?></td>
          <td><?= h($l['memberName']) ?></td>
          <td><?= h(fmt_date($l['issued'])) ?></td>
          <td><?= loan_stamp($l) ?></td>
          <td class="num"><?= $l['fine'] > 0 ? h(money($l['fine'])) : '—' ?></td>
          <td class="actions">
            <?php if ($l['active']): ?>
            <form method="post">
              <?= csrf_field() ?>
              <input type="hidden" name="loanId" value="<?= (int)$l['id'] ?>">
              <button type="submit" class="btn small">Return</button>
            </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
