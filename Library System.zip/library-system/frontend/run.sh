#!/bin/sh
# Starts the PHP front-end on http://localhost:8000  (needs PHP 7.4 or newer)
cd "$(dirname "$0")" || exit 1
php -S localhost:8000
