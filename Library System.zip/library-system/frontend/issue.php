<?php
require __DIR__ . '/config.php';
require_admin();

$error = null;
$bookId = (int)($_GET['book'] ?? $_POST['bookId'] ?? 0);
$memberId = (int)($_GET['member'] ?? $_POST['memberId'] ?? 0);
$days = (int)($_POST['days'] ?? 14);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $r = api_post('/loans/issue', ['bookId' => $bookId, 'memberId' => $memberId, 'days' => $days]);
    if ($r['ok']) {
        flash('ok', 'Book issued. It is due back on ' . fmt_date($r['data']['due']) . '.');
        redirect('loans.php');
    }
    $error = $r['error'];
}

$booksRes = api_get('/books', ['available' => 1]);
$membersRes = api_get('/members');
$books = $booksRes['data']['books'] ?? [];
$statsRes = api_get('/stats');
$finePerDay = $statsRes['data']['finePerDay'] ?? 0;
$maxLoans = $statsRes['data']['maxLoans'] ?? 3;
$members = array_filter($membersRes['data']['members'] ?? [], function ($m) { return $m['active']; });
$error = $error ?: $booksRes['error'] ?: $membersRes['error'];

$title = 'Issue a book';
$nav = 'issue';
require __DIR__ . '/includes/header.php';
show_error($error);
?>
<section class="panel form-panel">
  <form method="post" class="stack">
    <?= csrf_field() ?>
    <label>Book <span class="muted small">(only titles with a copy on the shelf)</span>
      <select name="bookId" required>
        <option value="">Choose a book</option>
        <?php foreach ($books as $b): ?>
          <option value="<?= (int)$b['id'] ?>"<?= selected($b['id'], $bookId) ?>><?= h($b['title']) ?> — <?= h($b['author']) ?> (<?= (int)$b['available'] ?> in)</option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Member
      <select name="memberId" required>
        <option value="">Choose a member</option>
        <?php foreach ($members as $m): ?>
          <option value="<?= (int)$m['id'] ?>"<?= selected($m['id'], $memberId) ?>><?= h($m['name']) ?> (<?= (int)$m['activeLoans'] ?> out)</option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Loan period in days
      <input name="days" type="number" min="1" max="90" required value="<?= $days ?>">
    </label>
    <p class="muted small">Members can hold up to <?= (int)$maxLoans ?> books at once. Late returns are charged <?= h(money($finePerDay)) ?> per day.</p>
    <div class="buttons">
      <button class="btn primary" type="submit">Issue book</button>
      <a class="btn" href="loans.php">Cancel</a>
    </div>
  </form>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
