<?php
require __DIR__ . '/config.php';

$as = $_GET['as'] ?? $_POST['as'] ?? '';
if (!in_array($as, ['student', 'librarian'], true)) {
    redirect('index.php');
}
if (!empty($_SESSION['user'])) {
    redirect(home_for_role());
}
$isLibrarian = $as === 'librarian';

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $r = api_post('/login', [
        'username' => $_POST['username'] ?? '',
        'password' => $_POST['password'] ?? '',
    ]);
    if (!$r['ok']) {
        $error = $r['error'];
    } elseif ($isLibrarian && $r['data']['role'] !== 'admin') {
        $error = 'That is a student account. Go back and choose “I’m a student” to sign in.';
    } elseif (!$isLibrarian && $r['data']['role'] === 'admin') {
        $error = 'That is a librarian account. Go back and choose “I’m a librarian” to sign in.';
    } else {
        start_session_for($r['data']);
        redirect(home_for_role());
    }
}

$title = $isLibrarian ? 'Librarian sign in' : 'Student sign in';
$bare = true;
require __DIR__ . '/includes/header.php';
?>
<section class="auth-card">
  <a class="back" href="index.php">Back to start</a>
  <h1><?= h($title) ?></h1>
  <p class="muted">
    <?= $isLibrarian ? 'Use the librarian account provided by your library.' : 'Welcome back. Sign in to see your books and requests.' ?>
  </p>
  <?php show_error($error); ?>
  <form method="post" class="stack">
    <?= csrf_field() ?>
    <input type="hidden" name="as" value="<?= h($as) ?>">
    <label>Username
      <input name="username" autocomplete="username" required autofocus value="<?= h($_POST['username'] ?? '') ?>">
    </label>
    <label>Password
      <input name="password" type="password" autocomplete="current-password" required>
    </label>
    <button class="btn primary" type="submit">Sign in</button>
  </form>
  <?php if (!$isLibrarian): ?>
    <p class="alt">New here? <a href="register.php">Create a student account</a></p>
  <?php else: ?>
    <p class="hint">Librarian accounts can’t be created here. If you’ve lost the password, ask the person who set up the system.</p>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
