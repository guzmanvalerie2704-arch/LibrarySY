<?php
require __DIR__ . '/config.php';
require_admin();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$editing = $id > 0;
$error = null;
$member = ['name' => '', 'email' => '', 'phone' => '', 'active' => true];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $member = [
        'name'   => trim($_POST['name'] ?? ''),
        'email'  => trim($_POST['email'] ?? ''),
        'phone'  => trim($_POST['phone'] ?? ''),
        'active' => !empty($_POST['active']),
    ];
    $r = api_post($editing ? "/members/$id/update" : '/members', [
        'name' => $member['name'], 'email' => $member['email'],
        'phone' => $member['phone'], 'active' => $member['active'] ? '1' : '0',
    ]);
    if ($r['ok']) {
        flash('ok', $editing ? 'Changes saved.' : $member['name'] . ' is now a member.');
        redirect('members.php');
    }
    $error = $r['error'];
} elseif ($editing) {
    $r = api_get("/members/$id");
    if (!$r['ok']) {
        flash('error', $r['error']);
        redirect('members.php');
    }
    $member = $r['data'];
}

$title = $editing ? 'Edit member' : 'Add a member';
$nav = 'members';
require __DIR__ . '/includes/header.php';
show_error($error);
?>
<section class="panel form-panel">
  <form method="post" class="stack">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= $id ?>">
    <label>Full name
      <input name="name" required maxlength="120" value="<?= h($member['name']) ?>" autofocus>
    </label>
    <div class="row">
      <label>Email
        <input name="email" type="email" maxlength="120" value="<?= h($member['email']) ?>">
      </label>
      <label>Phone
        <input name="phone" maxlength="30" value="<?= h($member['phone']) ?>">
      </label>
    </div>
    <label class="check"><input type="checkbox" name="active" value="1"<?= $member['active'] ? ' checked' : '' ?>> Membership is active (inactive members can’t borrow)</label>
    <div class="buttons">
      <button class="btn primary" type="submit"><?= $editing ? 'Save changes' : 'Add member' ?></button>
      <a class="btn" href="members.php">Cancel</a>
    </div>
  </form>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
