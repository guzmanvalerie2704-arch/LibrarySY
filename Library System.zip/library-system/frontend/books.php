<?php
require __DIR__ . '/config.php';
require_admin();

// Delete a book (POST from the table below).
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $r = api_post('/books/' . (int)($_POST['id'] ?? 0) . '/delete');
    $r['ok'] ? flash('ok', 'Book deleted.') : flash('error', $r['error']);
    redirect('books.php');
}

$q = trim($_GET['q'] ?? '');
$category = trim($_GET['category'] ?? '');
$onlyAvailable = !empty($_GET['available']);

$res = api_get('/books', ['q' => $q, 'category' => $category, 'available' => $onlyAvailable ? 1 : 0]);
$books = $res['data']['books'] ?? [];
$categories = $res['data']['categories'] ?? [];

$title = 'Books';
$nav = 'books';
$headActions = '<a class="btn primary" href="book_form.php">Add a book</a>';
require __DIR__ . '/includes/header.php';
show_error($res['error']);
?>
<form class="filters" method="get">
  <label class="grow">Search
    <input type="search" name="q" value="<?= h($q) ?>" placeholder="Title, author or ISBN">
  </label>
  <label>Category
    <select name="category">
      <option value="">All categories</option>
      <?php foreach ($categories as $c): ?>
        <option<?= selected($c, $category) ?>><?= h($c) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label class="check"><input type="checkbox" name="available" value="1"<?= $onlyAvailable ? ' checked' : '' ?>> Only available</label>
  <button class="btn" type="submit">Search</button>
</form>

<section class="panel">
  <?php if (!$books): ?>
    <p class="empty"><?= ($q || $category || $onlyAvailable) ? 'No books match that search. Try fewer filters.' : 'No books yet.' ?>
      <a href="book_form.php">Add a book</a></p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Title</th><th>Category</th><th>ISBN</th><th>On the shelf</th><th class="actions">Actions</th></tr></thead>
      <tbody>
      <?php foreach ($books as $b): ?>
        <tr>
          <td><strong><?= h($b['title']) ?></strong><br><span class="muted"><?= h($b['author']) ?></span></td>
          <td><?= h($b['category'] ?: '—') ?></td>
          <td class="mono"><?= h($b['isbn'] ?: '—') ?></td>
          <td><?= pips((int)$b['available'], (int)$b['copies']) ?> <span class="muted small"><?= (int)$b['available'] ?> of <?= (int)$b['copies'] ?></span></td>
          <td class="actions">
            <?php if ($b['available'] > 0): ?><a href="issue.php?book=<?= (int)$b['id'] ?>">Issue</a><?php endif; ?>
            <a href="book_form.php?id=<?= (int)$b['id'] ?>">Edit</a>
            <a href="loans.php?book=<?= (int)$b['id'] ?>">History</a>
            <form method="post" onsubmit="return confirm('Delete “<?= h(addslashes($b['title'])) ?>”? This can’t be undone.');">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
              <button type="submit" class="link danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
