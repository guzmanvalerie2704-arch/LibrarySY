<?php
require __DIR__ . '/config.php';
require_student();
$mid = (int)$_SESSION['memberId'];

$q = trim($_GET['q'] ?? $_POST['q'] ?? '');
$category = trim($_GET['category'] ?? $_POST['category'] ?? '');
$onlyAvailable = !empty($_GET['available'] ?? $_POST['available'] ?? '');

// Ask to borrow a book.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $r = api_post('/reservations', ['bookId' => (int)($_POST['bookId'] ?? 0), 'memberId' => $mid]);
    $r['ok']
        ? flash('ok', 'Request sent. The librarian will approve it, and you can pick the book up at the desk.')
        : flash('error', $r['error']);
    redirect('catalog.php?' . http_build_query(array_filter(['q' => $q, 'category' => $category, 'available' => $onlyAvailable ? 1 : null])));
}

$res = api_get('/books', ['q' => $q, 'category' => $category, 'available' => $onlyAvailable ? 1 : 0]);
$books = $res['data']['books'] ?? [];
$categories = $res['data']['categories'] ?? [];

$myLoans = api_get('/loans', ['status' => 'active', 'member' => $mid]);
$myPending = api_get('/reservations', ['status' => 'pending', 'member' => $mid]);
$held = array_column($myLoans['data']['loans'] ?? [], 'bookId');
$requested = array_column($myPending['data']['reservations'] ?? [], 'bookId');

$title = 'Find a book';
$nav = 'catalog';
require __DIR__ . '/includes/header.php';
show_error($res['error']);
?>
<form class="filters" method="get">
  <label class="grow">Search
    <input type="search" name="q" value="<?= h($q) ?>" placeholder="Title, author or ISBN">
  </label>
  <label>Category
    <select name="category">
      <option value="">All categories</option>
      <?php foreach ($categories as $c): ?>
        <option<?= selected($c, $category) ?>><?= h($c) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label class="check"><input type="checkbox" name="available" value="1"<?= $onlyAvailable ? ' checked' : '' ?>> Only on the shelf</label>
  <button class="btn" type="submit">Search</button>
</form>
<p class="muted small help">The librarian approves each request. If no copy is on the shelf, your request waits until one is returned.</p>

<section class="panel">
  <?php if (!$books): ?>
    <p class="empty"><?= ($q || $category || $onlyAvailable) ? 'No books match that search. Try fewer filters.' : 'The catalog is empty.' ?></p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Title</th><th>Category</th><th>On the shelf</th><th class="actions">Borrow</th></tr></thead>
      <tbody>
      <?php foreach ($books as $b): ?>
        <tr>
          <td><strong><?= h($b['title']) ?></strong><br><span class="muted"><?= h($b['author']) ?></span></td>
          <td><?= h($b['category'] ?: '—') ?></td>
          <td><?= pips((int)$b['available'], (int)$b['copies']) ?> <span class="muted small"><?= (int)$b['available'] ?> of <?= (int)$b['copies'] ?></span></td>
          <td class="actions">
            <?php if (in_array($b['id'], $held)): ?>
              <span class="tag on">You have it</span>
            <?php elseif (in_array($b['id'], $requested)): ?>
              <span class="tag wait">Requested</span>
            <?php else: ?>
              <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="bookId" value="<?= (int)$b['id'] ?>">
                <input type="hidden" name="q" value="<?= h($q) ?>">
                <input type="hidden" name="category" value="<?= h($category) ?>">
                <input type="hidden" name="available" value="<?= $onlyAvailable ? 1 : '' ?>">
                <button type="submit" class="btn small"><?= $b['available'] > 0 ? 'Request' : 'Reserve' ?></button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
