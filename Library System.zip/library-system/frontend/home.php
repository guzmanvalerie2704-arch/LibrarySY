<?php
require __DIR__ . '/config.php';
require_student();
$mid = (int)$_SESSION['memberId'];

$activeRes = api_get('/loans', ['status' => 'active', 'member' => $mid]);
$pastRes = api_get('/loans', ['status' => 'returned', 'member' => $mid]);
$reqRes = api_get('/reservations', ['status' => 'pending', 'member' => $mid]);
$error = $activeRes['error'] ?: $pastRes['error'] ?: $reqRes['error'];

$active = $activeRes['data']['loans'] ?? [];
usort($active, function ($a, $b) { return strcmp($a['due'], $b['due']); });
$past = array_slice($pastRes['data']['loans'] ?? [], 0, 10);
$pending = count($reqRes['data']['reservations'] ?? []);

$overdue = 0;
$owed = 0.0;
foreach ($active as $l) {
    if ($l['overdue']) { $overdue++; }
    $owed += $l['fine'];
}
$charged = 0.0;
foreach ($pastRes['data']['loans'] ?? [] as $l) {
    $charged += $l['fine'];
}

$title = 'My books';
$nav = 'home';
$headActions = '<a class="btn primary" href="catalog.php">Find a book</a>';
require __DIR__ . '/includes/header.php';
show_error($error);
?>
<section class="ledger" aria-label="Your library account">
  <div><b><?= count($active) ?></b><span>books you have</span></div>
  <div class="<?= $overdue > 0 ? 'alert' : '' ?>"><b><?= $overdue ?></b><span>overdue</span></div>
  <div class="<?= $owed > 0 ? 'alert' : '' ?>"><b><?= h(money($owed)) ?></b><span>fines building up now</span></div>
  <div><b><?= $pending ?></b><span>requests waiting</span></div>
</section>
<?php if ($overdue > 0): ?>
  <div class="notice bad">You have overdue books. Please return them to the library desk. Fines grow every day.</div>
<?php endif; ?>

<section class="panel">
  <div class="panel-head"><h2>Books you have</h2></div>
  <?php if (!$active): ?>
    <p class="empty">You don’t have any books right now. <a href="catalog.php">Find something to read.</a></p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Book</th><th>Borrowed</th><th>Status</th><th class="num">Fine so far</th></tr></thead>
      <tbody>
      <?php foreach ($active as $l): ?>
        <tr>
          <td><?= h($l['bookTitle']) ?></td>
          <td><?= h(fmt_date($l['issued'])) ?></td>
          <td><?= loan_stamp($l) ?></td>
          <td class="num"><?= $l['fine'] > 0 ? h(money($l['fine'])) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</section>

<section class="panel spaced">
  <div class="panel-head"><h2>Returned books</h2><span class="muted small">Fines charged so far: <?= h(money($charged)) ?></span></div>
  <?php if (!$past): ?>
    <p class="empty">Books you return will show up here.</p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Book</th><th>Borrowed</th><th>Status</th><th class="num">Fine</th></tr></thead>
      <tbody>
      <?php foreach ($past as $l): ?>
        <tr>
          <td><?= h($l['bookTitle']) ?></td>
          <td><?= h(fmt_date($l['issued'])) ?></td>
          <td><?= loan_stamp($l) ?></td>
          <td class="num"><?= $l['fine'] > 0 ? h(money($l['fine'])) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
