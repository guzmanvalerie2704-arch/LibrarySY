<?php
require __DIR__ . '/config.php';
require_admin();

$view = ($_GET['view'] ?? $_POST['view'] ?? 'pending') === 'all' ? 'all' : 'pending';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $id = (int)($_POST['id'] ?? 0);
    if (($_POST['action'] ?? '') === 'approve') {
        $r = api_post("/reservations/$id/approve", ['days' => (int)($_POST['days'] ?? 14)]);
        $r['ok']
            ? flash('ok', 'Approved and issued. It is due back on ' . fmt_date($r['data']['due']) . '.')
            : flash('error', $r['error']);
    } else {
        $r = api_post("/reservations/$id/reject", ['note' => trim($_POST['note'] ?? '')]);
        $r['ok'] ? flash('ok', 'Request declined.') : flash('error', $r['error']);
    }
    redirect('requests.php?view=' . $view);
}

$res = api_get('/reservations', ['status' => $view]);
$requests = $res['data']['reservations'] ?? [];
if ($view === 'pending') {
    usort($requests, function ($a, $b) { return $a['id'] <=> $b['id']; }); // oldest first
}

$title = 'Borrow requests';
$nav = 'requests';
require __DIR__ . '/includes/header.php';
show_error($res['error']);
?>
<nav class="tabs" aria-label="Request filter">
  <a href="requests.php?view=pending"<?= $view === 'pending' ? ' class="current" aria-current="page"' : '' ?>>Waiting</a>
  <a href="requests.php?view=all"<?= $view === 'all' ? ' class="current" aria-current="page"' : '' ?>>All requests</a>
</nav>

<section class="panel">
  <?php if (!$requests): ?>
    <p class="empty"><?= $view === 'pending' ? 'No requests are waiting. Students’ requests will show up here.' : 'No requests yet.' ?></p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Requested</th><th>Student</th><th>Book</th><th>On the shelf</th><th><?= $view === 'pending' ? 'Decision' : 'Status' ?></th></tr></thead>
      <tbody>
      <?php foreach ($requests as $r): ?>
        <tr>
          <td><?= h(fmt_date($r['requested'])) ?></td>
          <td><a href="loans.php?member=<?= (int)$r['memberId'] ?>"><?= h($r['memberName']) ?></a><br>
            <span class="muted small"><?= (int)$r['memberLoans'] ?> book<?= $r['memberLoans'] == 1 ? '' : 's' ?> out</span></td>
          <td><?= h($r['bookTitle']) ?></td>
          <td><?= (int)$r['bookAvailable'] ?></td>
          <td>
            <?php if ($r['status'] === 'pending'): ?>
              <?php if ($r['bookAvailable'] > 0): ?>
              <form method="post" class="inline-form">
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <input type="hidden" name="view" value="<?= h($view) ?>">
                <input type="hidden" name="action" value="approve">
                <input class="days" name="days" type="number" min="1" max="90" value="14" aria-label="Loan days">
                <span class="muted small">days</span>
                <button class="btn primary small" type="submit">Approve and issue</button>
              </form>
              <?php else: ?>
                <span class="muted small">No copy is back yet</span>
              <?php endif; ?>
              <form method="post" class="inline-form decline">
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <input type="hidden" name="view" value="<?= h($view) ?>">
                <input type="hidden" name="action" value="reject">
                <input name="note" maxlength="120" placeholder="Reason (optional)" aria-label="Reason for declining">
                <button class="btn small" type="submit">Decline</button>
              </form>
            <?php else: ?>
              <?= request_tag($r) ?> <span class="muted small"><?= h($r['note']) ?></span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
