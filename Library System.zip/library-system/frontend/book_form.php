<?php
require __DIR__ . '/config.php';
require_admin();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$editing = $id > 0;
$error = null;
$book = ['title' => '', 'author' => '', 'isbn' => '', 'category' => '', 'copies' => 1];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    foreach ($book as $k => $_) {
        $book[$k] = trim($_POST[$k] ?? '');
    }
    $r = api_post($editing ? "/books/$id/update" : '/books', $book);
    if ($r['ok']) {
        flash('ok', $editing ? 'Changes saved.' : '“' . $book['title'] . '” added to the library.');
        redirect('books.php');
    }
    $error = $r['error'];
} elseif ($editing) {
    $r = api_get("/books/$id");
    if (!$r['ok']) {
        flash('error', $r['error']);
        redirect('books.php');
    }
    $book = $r['data'];
}

$catRes = api_get('/books');
$categories = $catRes['data']['categories'] ?? [];

$title = $editing ? 'Edit book' : 'Add a book';
$nav = 'books';
require __DIR__ . '/includes/header.php';
show_error($error);
?>
<section class="panel form-panel">
  <form method="post" class="stack">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= $id ?>">
    <label>Title
      <input name="title" required maxlength="200" value="<?= h($book['title']) ?>" autofocus>
    </label>
    <label>Author
      <input name="author" required maxlength="120" value="<?= h($book['author']) ?>">
    </label>
    <div class="row">
      <label>ISBN <span class="muted small">(optional, must be unique)</span>
        <input name="isbn" maxlength="20" value="<?= h($book['isbn']) ?>">
      </label>
      <label>Category
        <input name="category" maxlength="60" list="cats" value="<?= h($book['category']) ?>">
        <datalist id="cats"><?php foreach ($categories as $c): ?><option value="<?= h($c) ?>"><?php endforeach; ?></datalist>
      </label>
      <label>Copies owned
        <input name="copies" type="number" min="1" max="999" required value="<?= h($book['copies']) ?>">
      </label>
    </div>
    <div class="buttons">
      <button class="btn primary" type="submit"><?= $editing ? 'Save changes' : 'Add book' ?></button>
      <a class="btn" href="books.php">Cancel</a>
    </div>
  </form>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
