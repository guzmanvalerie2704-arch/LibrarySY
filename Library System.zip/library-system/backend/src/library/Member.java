package library;

import java.util.LinkedHashMap;
import java.util.Map;

public class Member {
    public int id;
    public String name, email, phone, joined;
    public boolean active = true;

    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("name", name);
        m.put("email", email);
        m.put("phone", phone);
        m.put("joined", joined);
        m.put("active", active);
        return m;
    }

    String toLine() {
        return Store.join(id, name, email, phone, joined, active);
    }

    static Member fromLine(String line) {
        String[] f = Store.split(line, 6);
        Member m = new Member();
        m.id = Integer.parseInt(f[0]);
        m.name = f[1];
        m.email = f[2];
        m.phone = f[3];
        m.joined = f[4];
        m.active = Boolean.parseBoolean(f[5]);
        return m;
    }
}
