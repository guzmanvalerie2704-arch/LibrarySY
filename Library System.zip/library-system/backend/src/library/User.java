package library;

import java.util.LinkedHashMap;
import java.util.Map;

public class User {
    public int id, memberId;      // memberId is 0 for admins
    public String username, passHash, role, name; // role: "admin" or "student"

    public boolean isAdmin() { return "admin".equals(role); }

    public Map<String, Object> toMap(String displayName) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("username", username);
        m.put("name", displayName);
        m.put("role", role);
        m.put("memberId", memberId);
        return m;
    }

    String toLine() {
        return Store.join(id, username, passHash, role, memberId, name);
    }

    static User fromLine(String line) {
        String[] f = Store.split(line, 6);
        User u = new User();
        u.id = Integer.parseInt(f[0]);
        u.username = f[1];
        u.passHash = f[2];
        u.role = f[3];
        u.memberId = Integer.parseInt(f[4]);
        u.name = f[5];
        return u;
    }
}
