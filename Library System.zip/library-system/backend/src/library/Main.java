package library;

import com.sun.net.httpserver.HttpServer;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.file.Paths;
import java.util.concurrent.Executors;

public class Main {
    public static void main(String[] args) throws Exception {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 8080;
        String dataDir = args.length > 1 ? args[1] : "data";

        Store store = new Store(Paths.get(dataDir));
        // Only the local PHP front-end talks to this API, so listen on localhost only.
        HttpServer server = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), port), 0);
        server.createContext("/api", new Api(store));
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();

        System.out.println("Library API running at http://127.0.0.1:" + port + "/api");
        System.out.println("Data folder: " + Paths.get(dataDir).toAbsolutePath());
        System.out.println("Press Ctrl+C to stop.");
    }
}
