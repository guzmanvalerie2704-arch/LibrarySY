package library;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Loan {
    public int id, bookId, memberId;
    public LocalDate issued, due, returned; // returned == null while the book is out
    public double fine;                     // final fine, set when the book is returned

    public boolean isActive() { return returned == null; }

    public long overdueDays(LocalDate today) {
        LocalDate end = returned != null ? returned : today;
        return Math.max(0, ChronoUnit.DAYS.between(due, end));
    }

    /** Fine already charged (returned loans) or accruing right now (active loans). */
    public double currentFine(LocalDate today) {
        return returned != null ? fine : overdueDays(today) * Store.FINE_PER_DAY;
    }

    String toLine() {
        return Store.join(id, bookId, memberId, issued, due, returned == null ? "" : returned, fine);
    }

    static Loan fromLine(String line) {
        String[] f = Store.split(line, 7);
        Loan l = new Loan();
        l.id = Integer.parseInt(f[0]);
        l.bookId = Integer.parseInt(f[1]);
        l.memberId = Integer.parseInt(f[2]);
        l.issued = LocalDate.parse(f[3]);
        l.due = LocalDate.parse(f[4]);
        l.returned = f[5].isEmpty() ? null : LocalDate.parse(f[5]);
        l.fine = Double.parseDouble(f[6]);
        return l;
    }
}
