package library;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.time.LocalDate;
import java.util.*;

/**
 * All library data and business rules. Data is kept in memory and saved to
 * tab-separated files in the data folder after every change, so the project
 * runs with no database installed. All public methods are synchronized.
 */
public final class Store {
    public static final double FINE_PER_DAY = 5.0; // charged per day a book is late
    public static final int MAX_LOANS = 3;         // books one member can hold at once
    public static final int DEFAULT_LOAN_DAYS = 14;
    public static final int MAX_PENDING = 5;       // open requests one student can have

    private final Path dir;
    private final List<Book> books = new ArrayList<>();
    private final List<Member> members = new ArrayList<>();
    private final List<Loan> loans = new ArrayList<>();
    private final List<User> users = new ArrayList<>();
    private final List<Reservation> reservations = new ArrayList<>();
    private int nextBook = 1, nextMember = 1, nextLoan = 1, nextUser = 1, nextRes = 1;

    public Store(Path dir) throws IOException {
        this.dir = dir;
        Files.createDirectories(dir);
        boolean fresh = !Files.exists(dir.resolve("books.tsv"));
        boolean noUsers = !Files.exists(dir.resolve("users.tsv"));
        load();
        if (fresh) {
            seed();
            save();
        }
        if (noUsers) {
            createDefaultAccounts();
            save();
        }
    }

    // ---------- books ----------

    public synchronized List<Book> searchBooks(String q, String category, boolean onlyAvailable) {
        String needle = q == null ? "" : q.trim().toLowerCase();
        List<Book> out = new ArrayList<>();
        for (Book b : books) {
            if (!needle.isEmpty() && !(b.title.toLowerCase().contains(needle)
                    || b.author.toLowerCase().contains(needle)
                    || b.isbn.toLowerCase().contains(needle))) continue;
            if (category != null && !category.isBlank() && !b.category.equalsIgnoreCase(category)) continue;
            if (onlyAvailable && b.available <= 0) continue;
            out.add(b);
        }
        out.sort(Comparator.comparing(b -> b.title.toLowerCase()));
        return out;
    }

    public synchronized Book getBook(int id) {
        for (Book b : books) if (b.id == id) return b;
        throw ApiException.notFound("Book #" + id + " does not exist.");
    }

    public synchronized Book addBook(String title, String author, String isbn, String category, int copies) {
        validateBook(title, author, copies);
        checkIsbn(isbn, -1);
        Book b = new Book();
        b.id = nextBook++;
        fill(b, title, author, isbn, category);
        b.copies = copies;
        b.available = copies;
        books.add(b);
        save();
        return b;
    }

    public synchronized Book updateBook(int id, String title, String author, String isbn, String category, int copies) {
        Book b = getBook(id);
        validateBook(title, author, copies);
        checkIsbn(isbn, id);
        int out = b.copies - b.available;
        if (copies < out) {
            throw ApiException.conflict(out + " copies are currently on loan, so the total can't be lower than " + out + ".");
        }
        fill(b, title, author, isbn, category);
        b.copies = copies;
        b.available = copies - out;
        save();
        return b;
    }

    public synchronized void deleteBook(int id) {
        Book b = getBook(id);
        for (Loan l : loans) {
            if (l.bookId == id && l.isActive()) {
                throw ApiException.conflict("\"" + b.title + "\" is on loan. Return it before deleting.");
            }
        }
        for (Reservation r : reservations) {
            if (r.bookId == id && r.status.equals(Reservation.PENDING)) {
                r.status = Reservation.CANCELLED;
                r.note = "This book was removed from the library.";
            }
        }
        books.remove(b);
        save();
    }

    public synchronized List<String> categories() {
        TreeSet<String> set = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (Book b : books) if (!b.category.isBlank()) set.add(b.category);
        return new ArrayList<>(set);
    }

    private void validateBook(String title, String author, int copies) {
        if (title.isBlank()) throw ApiException.bad("Title is required.");
        if (author.isBlank()) throw ApiException.bad("Author is required.");
        if (copies < 1 || copies > 999) throw ApiException.bad("Copies must be between 1 and 999.");
    }

    private void checkIsbn(String isbn, int selfId) {
        if (isbn.isBlank()) return;
        for (Book other : books) {
            if (other.id != selfId && other.isbn.equalsIgnoreCase(isbn)) {
                throw ApiException.conflict("ISBN " + isbn + " is already used by \"" + other.title + "\".");
            }
        }
    }

    private void fill(Book b, String title, String author, String isbn, String category) {
        b.title = title.trim();
        b.author = author.trim();
        b.isbn = isbn.trim();
        b.category = category.trim();
    }

    // ---------- members ----------

    public synchronized List<Member> searchMembers(String q) {
        String needle = q == null ? "" : q.trim().toLowerCase();
        List<Member> out = new ArrayList<>();
        for (Member m : members) {
            if (needle.isEmpty() || m.name.toLowerCase().contains(needle)
                    || m.email.toLowerCase().contains(needle) || m.phone.contains(needle)) out.add(m);
        }
        out.sort(Comparator.comparing(m -> m.name.toLowerCase()));
        return out;
    }

    public synchronized Member getMember(int id) {
        for (Member m : members) if (m.id == id) return m;
        throw ApiException.notFound("Member #" + id + " does not exist.");
    }

    public synchronized Member addMember(String name, String email, String phone, boolean active) {
        if (name.isBlank()) throw ApiException.bad("Name is required.");
        validateEmail(email);
        Member m = new Member();
        m.id = nextMember++;
        m.name = name.trim();
        m.email = email.trim();
        m.phone = phone.trim();
        m.joined = LocalDate.now().toString();
        m.active = active;
        members.add(m);
        save();
        return m;
    }

    public synchronized Member updateMember(int id, String name, String email, String phone, boolean active) {
        Member m = getMember(id);
        if (name.isBlank()) throw ApiException.bad("Name is required.");
        validateEmail(email);
        m.name = name.trim();
        m.email = email.trim();
        m.phone = phone.trim();
        m.active = active;
        save();
        return m;
    }

    public synchronized void deleteMember(int id) {
        Member m = getMember(id);
        if (activeLoanCount(id) > 0) {
            throw ApiException.conflict(m.name + " still has books out. Return them before deleting.");
        }
        for (Reservation r : reservations) {
            if (r.memberId == id && r.status.equals(Reservation.PENDING)) {
                r.status = Reservation.CANCELLED;
                r.note = "Member was removed.";
            }
        }
        users.removeIf(u -> u.memberId == id);
        members.remove(m);
        save();
    }

    public synchronized int activeLoanCount(int memberId) {
        int n = 0;
        for (Loan l : loans) if (l.memberId == memberId && l.isActive()) n++;
        return n;
    }

    private void validateEmail(String email) {
        if (!email.isBlank() && !email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
            throw ApiException.bad("That email address doesn't look right.");
        }
    }

    // ---------- loans ----------

    public synchronized Loan issue(int bookId, int memberId, int days) {
        Book b = getBook(bookId);
        Member m = getMember(memberId);
        if (!m.active) throw ApiException.conflict(m.name + "'s membership is inactive.");
        if (days < 1 || days > 90) throw ApiException.bad("Loan period must be between 1 and 90 days.");
        if (b.available <= 0) throw ApiException.conflict("No copies of \"" + b.title + "\" are available.");
        if (activeLoanCount(memberId) >= MAX_LOANS) {
            throw ApiException.conflict(m.name + " already has " + MAX_LOANS + " books out, which is the limit.");
        }
        for (Loan l : loans) {
            if (l.isActive() && l.bookId == bookId && l.memberId == memberId) {
                throw ApiException.conflict(m.name + " already has a copy of \"" + b.title + "\".");
            }
        }
        Loan l = new Loan();
        l.id = nextLoan++;
        l.bookId = bookId;
        l.memberId = memberId;
        l.issued = LocalDate.now();
        l.due = l.issued.plusDays(days);
        loans.add(l);
        b.available--;
        save();
        return l;
    }

    public synchronized Loan returnBook(int loanId) {
        Loan l = findLoan(loanId);
        if (!l.isActive()) throw ApiException.conflict("That loan was already returned.");
        l.returned = LocalDate.now();
        l.fine = l.overdueDays(l.returned) * FINE_PER_DAY;
        for (Book b : books) {
            if (b.id == l.bookId) { b.available = Math.min(b.copies, b.available + 1); break; }
        }
        save();
        return l;
    }

    private Loan findLoan(int id) {
        for (Loan l : loans) if (l.id == id) return l;
        throw ApiException.notFound("Loan #" + id + " does not exist.");
    }

    /** status: "active", "overdue", "returned" or "all". Newest first. */
    public synchronized List<Map<String, Object>> loanViews(String status, Integer memberId, Integer bookId) {
        LocalDate today = LocalDate.now();
        List<Map<String, Object>> out = new ArrayList<>();
        for (int i = loans.size() - 1; i >= 0; i--) {
            Loan l = loans.get(i);
            boolean overdue = l.isActive() && today.isAfter(l.due);
            switch (status) {
                case "active" -> { if (!l.isActive()) continue; }
                case "overdue" -> { if (!overdue) continue; }
                case "returned" -> { if (l.isActive()) continue; }
                default -> { }
            }
            if (memberId != null && l.memberId != memberId) continue;
            if (bookId != null && l.bookId != bookId) continue;
            out.add(view(l, today, overdue));
        }
        return out;
    }

    private Map<String, Object> view(Loan l, LocalDate today, boolean overdue) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", l.id);
        m.put("bookId", l.bookId);
        m.put("bookTitle", titleOf(l.bookId));
        m.put("memberId", l.memberId);
        m.put("memberName", nameOf(l.memberId));
        m.put("issued", l.issued.toString());
        m.put("due", l.due.toString());
        m.put("returned", l.returned == null ? null : l.returned.toString());
        m.put("active", l.isActive());
        m.put("overdue", overdue);
        m.put("overdueDays", l.overdueDays(today));
        m.put("fine", l.currentFine(today));
        return m;
    }

    private String titleOf(int id) {
        for (Book b : books) if (b.id == id) return b.title;
        return "(deleted book)";
    }

    private String nameOf(int id) {
        for (Member m : members) if (m.id == id) return m.name;
        return "(deleted member)";
    }

    // ---------- accounts ----------

    public synchronized User authenticate(String username, String password) {
        User u = findUser(username);
        if (u == null || !verify(password, u.passHash)) {
            throw new ApiException(401, "Wrong username or password.");
        }
        return u;
    }

    /** Creates a student account. If the librarian already added a member with the same email, the account links to it. */
    public synchronized User register(String name, String email, String phone, String username, String password) {
        if (name.isBlank()) throw ApiException.bad("Full name is required.");
        if (email.isBlank()) throw ApiException.bad("Email is required so the library can contact you.");
        validateEmail(email);
        if (!username.matches("^[A-Za-z0-9_.]{3,30}$")) {
            throw ApiException.bad("Username must be 3 to 30 letters, numbers, dots or underscores.");
        }
        validatePassword(password);
        if (findUser(username) != null) throw ApiException.conflict("That username is taken. Try another.");

        Member m = null;
        for (Member x : members) if (x.email.equalsIgnoreCase(email.trim())) { m = x; break; }
        if (m != null) {
            for (User u : users) {
                if (u.memberId == m.id) throw ApiException.conflict("An account already exists for that email. Try signing in.");
            }
        } else {
            m = new Member();
            m.id = nextMember++;
            m.name = name.trim();
            m.email = email.trim();
            m.phone = phone.trim();
            m.joined = LocalDate.now().toString();
            m.active = true;
            members.add(m);
        }
        User u = new User();
        u.id = nextUser++;
        u.username = username.trim();
        u.passHash = hash(password);
        u.role = "student";
        u.memberId = m.id;
        u.name = m.name;
        users.add(u);
        save();
        return u;
    }

    public synchronized void changePassword(int userId, String current, String next) {
        User u = null;
        for (User x : users) if (x.id == userId) u = x;
        if (u == null) throw ApiException.notFound("Account not found.");
        if (!verify(current, u.passHash)) throw ApiException.bad("Your current password is wrong.");
        validatePassword(next);
        u.passHash = hash(next);
        save();
    }

    /** The name to show for an account: students use their member record's name. */
    public synchronized String displayName(User u) {
        if (!u.isAdmin()) {
            for (Member m : members) if (m.id == u.memberId) return m.name;
        }
        return u.name;
    }

    private User findUser(String username) {
        for (User u : users) if (u.username.equalsIgnoreCase(username.trim())) return u;
        return null;
    }

    private void validatePassword(String pw) {
        if (pw.length() < 6) throw ApiException.bad("Password must be at least 6 characters.");
        if (pw.length() > 100) throw ApiException.bad("Password is too long.");
    }

    private void createDefaultAccounts() {
        String adminName = envOr("LIB_ADMIN_USER", "admin");
        String adminPass = envOr("LIB_ADMIN_PASS", "admin123");
        User a = new User();
        a.id = nextUser++;
        a.username = adminName;
        a.passHash = hash(adminPass);
        a.role = "admin";
        a.memberId = 0;
        a.name = "Librarian";
        users.add(a);
        // Demo student linked to the sample member "Maria Santos", if she exists.
        for (Member m : members) {
            if (m.name.equals("Maria Santos") && m.email.equals("maria.santos@example.com")) {
                User s = new User();
                s.id = nextUser++;
                s.username = "maria";
                s.passHash = hash("student123");
                s.role = "student";
                s.memberId = m.id;
                s.name = m.name;
                users.add(s);
            }
        }
    }

    private static String envOr(String name, String fallback) {
        String v = System.getenv(name);
        return v == null || v.isBlank() ? fallback : v;
    }

    private static String hash(String password) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        Base64.Encoder enc = Base64.getEncoder();
        return enc.encodeToString(salt) + "$" + enc.encodeToString(pbkdf2(password, salt));
    }

    private static boolean verify(String password, String stored) {
        String[] parts = stored.split("\\$");
        if (parts.length != 2) return false;
        byte[] salt = Base64.getDecoder().decode(parts[0]);
        byte[] expected = Base64.getDecoder().decode(parts[1]);
        return MessageDigest.isEqual(expected, pbkdf2(password, salt));
    }

    private static byte[] pbkdf2(String password, byte[] salt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65_000, 256);
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    // ---------- borrow requests ----------

    public synchronized Reservation requestBook(int bookId, int memberId) {
        Book b = getBook(bookId);
        Member m = getMember(memberId);
        if (!m.active) throw ApiException.conflict("Your membership is inactive. Please see the librarian.");
        for (Loan l : loans) {
            if (l.isActive() && l.bookId == bookId && l.memberId == memberId) {
                throw ApiException.conflict("You already have a copy of \"" + b.title + "\".");
            }
        }
        int pending = 0;
        for (Reservation r : reservations) {
            if (r.memberId == memberId && r.status.equals(Reservation.PENDING)) {
                if (r.bookId == bookId) throw ApiException.conflict("You already have a pending request for \"" + b.title + "\".");
                pending++;
            }
        }
        if (pending >= MAX_PENDING) {
            throw ApiException.conflict("You have " + MAX_PENDING + " pending requests, which is the limit. Cancel one or wait for the librarian.");
        }
        Reservation r = new Reservation();
        r.id = nextRes++;
        r.bookId = bookId;
        r.memberId = memberId;
        r.requested = LocalDate.now();
        reservations.add(r);
        save();
        return r;
    }

    /** Approving a request issues the loan. Fails (and stays pending) if no copy is available or limits are hit. */
    public synchronized Loan approve(int id, int days) {
        Reservation r = findReservation(id);
        requirePending(r);
        Loan l = issue(r.bookId, r.memberId, days);
        r.status = Reservation.APPROVED;
        r.loanId = l.id;
        save();
        return l;
    }

    public synchronized void reject(int id, String note) {
        Reservation r = findReservation(id);
        requirePending(r);
        r.status = Reservation.REJECTED;
        r.note = note.trim();
        save();
    }

    /** Cancels a pending request. When memberId is given, it must be the request's owner. */
    public synchronized void cancelRequest(int id, Integer memberId) {
        Reservation r = findReservation(id);
        if (memberId != null && r.memberId != memberId) throw new ApiException(403, "That isn't your request.");
        requirePending(r);
        r.status = Reservation.CANCELLED;
        save();
    }

    public synchronized List<Map<String, Object>> reservationViews(String status, Integer memberId) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (int i = reservations.size() - 1; i >= 0; i--) {
            Reservation r = reservations.get(i);
            if (!status.equals("all") && !r.status.equals(status)) continue;
            if (memberId != null && r.memberId != memberId) continue;
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", r.id);
            m.put("bookId", r.bookId);
            m.put("bookTitle", titleOf(r.bookId));
            m.put("bookAvailable", availableOf(r.bookId));
            m.put("memberId", r.memberId);
            m.put("memberName", nameOf(r.memberId));
            m.put("memberLoans", activeLoanCount(r.memberId));
            m.put("requested", r.requested.toString());
            m.put("status", r.status);
            m.put("note", r.note);
            m.put("loanId", r.loanId);
            out.add(m);
        }
        return out;
    }

    private Reservation findReservation(int id) {
        for (Reservation r : reservations) if (r.id == id) return r;
        throw ApiException.notFound("Request #" + id + " does not exist.");
    }

    private void requirePending(Reservation r) {
        if (!r.status.equals(Reservation.PENDING)) {
            throw ApiException.conflict("That request was already " + r.status + ".");
        }
    }

    private int availableOf(int bookId) {
        for (Book b : books) if (b.id == bookId) return b.available;
        return 0;
    }

    // ---------- dashboard ----------

    public synchronized Map<String, Object> stats() {
        LocalDate today = LocalDate.now();
        int copies = 0, available = 0, active = 0, overdue = 0;
        double accruing = 0, collected = 0;
        for (Book b : books) { copies += b.copies; available += b.available; }
        for (Loan l : loans) {
            if (l.isActive()) {
                active++;
                if (today.isAfter(l.due)) overdue++;
                accruing += l.currentFine(today);
            } else {
                collected += l.fine;
            }
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("titles", books.size());
        m.put("copies", copies);
        m.put("available", available);
        m.put("members", members.size());
        m.put("activeLoans", active);
        m.put("overdueLoans", overdue);
        m.put("finesAccruing", accruing);
        m.put("finesCharged", collected);
        m.put("finePerDay", FINE_PER_DAY);
        m.put("maxLoans", MAX_LOANS);
        m.put("pendingRequests", (int) reservations.stream().filter(r -> r.status.equals(Reservation.PENDING)).count());
        return m;
    }

    // ---------- persistence ----------

    private void load() throws IOException {
        for (String line : readLines("books.tsv")) { Book b = Book.fromLine(line); books.add(b); nextBook = Math.max(nextBook, b.id + 1); }
        for (String line : readLines("members.tsv")) { Member m = Member.fromLine(line); members.add(m); nextMember = Math.max(nextMember, m.id + 1); }
        for (String line : readLines("loans.tsv")) { Loan l = Loan.fromLine(line); loans.add(l); nextLoan = Math.max(nextLoan, l.id + 1); }
        for (String line : readLines("users.tsv")) { User u = User.fromLine(line); users.add(u); nextUser = Math.max(nextUser, u.id + 1); }
        for (String line : readLines("reservations.tsv")) { Reservation r = Reservation.fromLine(line); reservations.add(r); nextRes = Math.max(nextRes, r.id + 1); }
    }

    private List<String> readLines(String file) throws IOException {
        Path p = dir.resolve(file);
        if (!Files.exists(p)) return List.of();
        List<String> out = new ArrayList<>();
        for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) if (!line.isBlank()) out.add(line);
        return out;
    }

    private void save() {
        try {
            write("books.tsv", books.stream().map(Book::toLine).toList());
            write("members.tsv", members.stream().map(Member::toLine).toList());
            write("loans.tsv", loans.stream().map(Loan::toLine).toList());
            write("users.tsv", users.stream().map(User::toLine).toList());
            write("reservations.tsv", reservations.stream().map(Reservation::toLine).toList());
        } catch (IOException e) {
            throw new ApiException(500, "Could not save data: " + e.getMessage());
        }
    }

    private void write(String file, List<String> lines) throws IOException {
        Path tmp = dir.resolve(file + ".tmp");
        Files.write(tmp, lines, StandardCharsets.UTF_8);
        Files.move(tmp, dir.resolve(file), StandardCopyOption.REPLACE_EXISTING);
    }

    static String join(Object... fields) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
            if (i > 0) sb.append('\t');
            sb.append(escape(String.valueOf(fields[i])));
        }
        return sb.toString();
    }

    static String[] split(String line, int expected) {
        String[] raw = line.split("\t", -1);
        if (raw.length != expected) throw new IllegalStateException("Corrupt data line: " + line);
        for (int i = 0; i < raw.length; i++) raw[i] = unescape(raw[i]);
        return raw;
    }

    private static String escape(String s) {
        return s.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "\\r");
    }

    private static String unescape(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                sb.append(n == 't' ? '\t' : n == 'n' ? '\n' : n == 'r' ? '\r' : n);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    // ---------- sample data ----------

    private void seed() {
        String[][] data = {
            {"Noli Me Tangere", "José Rizal", "9780143039693", "Classics", "3"},
            {"El Filibusterismo", "José Rizal", "9780824826314", "Classics", "2"},
            {"Clean Code", "Robert C. Martin", "9780132350884", "Computing", "2"},
            {"Introduction to Algorithms", "Thomas H. Cormen", "9780262046305", "Computing", "1"},
            {"Effective Java", "Joshua Bloch", "9780134685991", "Computing", "2"},
            {"A Brief History of Time", "Stephen Hawking", "9780553380163", "Science", "2"},
            {"Sapiens", "Yuval Noah Harari", "9780062316097", "History", "3"},
            {"The Hobbit", "J.R.R. Tolkien", "9780547928227", "Fiction", "2"},
        };
        for (String[] d : data) addBookQuiet(d[0], d[1], d[2], d[3], Integer.parseInt(d[4]));
        String[][] people = {
            {"Maria Santos", "maria.santos@example.com", "0917 555 0101"},
            {"Juan dela Cruz", "juan.delacruz@example.com", "0918 555 0102"},
            {"Ana Reyes", "ana.reyes@example.com", "0920 555 0103"},
        };
        for (String[] p : people) {
            Member m = new Member();
            m.id = nextMember++;
            m.name = p[0]; m.email = p[1]; m.phone = p[2];
            m.joined = LocalDate.now().minusDays(90).toString();
            members.add(m);
        }
        addLoanQuiet(3, 1, 20, 6);  // Clean Code, overdue by 6 days
        addLoanQuiet(8, 2, 3, -11); // The Hobbit, due in 11 days
    }

    private void addBookQuiet(String t, String a, String i, String c, int n) {
        Book b = new Book();
        b.id = nextBook++;
        b.title = t; b.author = a; b.isbn = i; b.category = c;
        b.copies = n; b.available = n;
        books.add(b);
    }

    private void addLoanQuiet(int bookId, int memberId, int daysAgo, int overdueBy) {
        Loan l = new Loan();
        l.id = nextLoan++;
        l.bookId = bookId;
        l.memberId = memberId;
        l.issued = LocalDate.now().minusDays(daysAgo);
        l.due = LocalDate.now().minusDays(overdueBy);
        loans.add(l);
        getBook(bookId).available--;
    }
}
