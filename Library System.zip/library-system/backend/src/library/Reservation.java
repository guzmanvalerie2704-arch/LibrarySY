package library;

import java.time.LocalDate;

/** A student's request to borrow a book. The librarian approves (which issues the loan) or declines. */
public class Reservation {
    public static final String PENDING = "pending", APPROVED = "approved",
            REJECTED = "rejected", CANCELLED = "cancelled";

    public int id, bookId, memberId, loanId; // loanId is 0 until approved
    public LocalDate requested;
    public String status = PENDING, note = "";

    String toLine() {
        return Store.join(id, bookId, memberId, requested, status, note, loanId);
    }

    static Reservation fromLine(String line) {
        String[] f = Store.split(line, 7);
        Reservation r = new Reservation();
        r.id = Integer.parseInt(f[0]);
        r.bookId = Integer.parseInt(f[1]);
        r.memberId = Integer.parseInt(f[2]);
        r.requested = LocalDate.parse(f[3]);
        r.status = f[4];
        r.note = f[5];
        r.loanId = Integer.parseInt(f[6]);
        return r;
    }
}
