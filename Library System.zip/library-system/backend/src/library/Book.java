package library;

import java.util.LinkedHashMap;
import java.util.Map;

public class Book {
    public int id;
    public String title, author, isbn, category;
    public int copies, available;

    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("title", title);
        m.put("author", author);
        m.put("isbn", isbn);
        m.put("category", category);
        m.put("copies", copies);
        m.put("available", available);
        return m;
    }

    String toLine() {
        return Store.join(id, title, author, isbn, category, copies, available);
    }

    static Book fromLine(String line) {
        String[] f = Store.split(line, 7);
        Book b = new Book();
        b.id = Integer.parseInt(f[0]);
        b.title = f[1];
        b.author = f[2];
        b.isbn = f[3];
        b.category = f[4];
        b.copies = Integer.parseInt(f[5]);
        b.available = Integer.parseInt(f[6]);
        return b;
    }
}
