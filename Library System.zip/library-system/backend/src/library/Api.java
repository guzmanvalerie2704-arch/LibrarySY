package library;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * REST routes. Requests use query strings / form-encoded bodies, responses are JSON.
 *
 *   POST /api/login                       username, password   -> role, memberId, name
 *   POST /api/register                    name, email, phone, username, password (creates a student)
 *   POST /api/users/{id}/password         current, next
 *   GET  /api/stats
 *   GET  /api/books?q=&category=&available=1      POST /api/books
 *   GET  /api/books/{id}                          POST /api/books/{id}/update | /delete
 *   GET  /api/members?q=                          POST /api/members
 *   GET  /api/members/{id}                        POST /api/members/{id}/update | /delete
 *   GET  /api/loans?status=active|overdue|returned|all&member=&book=
 *   POST /api/loans/issue                         bookId, memberId, days
 *   POST /api/loans/return                        loanId
 *   GET  /api/reservations?status=pending|approved|rejected|cancelled|all&member=
 *   POST /api/reservations                        bookId, memberId   (student asks to borrow)
 *   POST /api/reservations/{id}/approve           days               (issues the loan)
 *   POST /api/reservations/{id}/reject            note
 *   POST /api/reservations/{id}/cancel            memberId (optional, must own the request)
 */
public class Api implements HttpHandler {
    private final Store store;

    public Api(Store store) { this.store = store; }

    @Override
    public void handle(HttpExchange ex) throws IOException {
        int status = 200;
        Object body;
        try {
            Map<String, String> p = parse(ex.getRequestURI().getRawQuery());
            String method = ex.getRequestMethod();
            if (method.equals("POST")) {
                p.putAll(parse(new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8)));
            } else if (!method.equals("GET")) {
                throw new ApiException(405, "Method not allowed.");
            }
            String path = ex.getRequestURI().getPath().replaceFirst("^/api/?", "");
            String[] seg = path.isEmpty() ? new String[0] : path.split("/");
            body = route(method, seg, p);
        } catch (ApiException e) {
            status = e.status;
            body = Map.of("error", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            status = 500;
            body = Map.of("error", "Unexpected server error.");
        }
        byte[] out = Json.stringify(body).getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(status, out.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(out); }
    }

    private Object route(String method, String[] seg, Map<String, String> p) {
        if (seg.length == 0) throw ApiException.notFound("Unknown endpoint.");
        return switch (seg[0]) {
            case "login" -> { requirePost(method); yield login(p); }
            case "register" -> { requirePost(method); yield register(p); }
            case "users" -> users(method, seg, p);
            case "reservations" -> reservations(method, seg, p);
            case "stats" -> store.stats();
            case "books" -> books(method, seg, p);
            case "members" -> members(method, seg, p);
            case "loans" -> loans(method, seg, p);
            default -> throw ApiException.notFound("Unknown endpoint.");
        };
    }

    // ----- auth -----

    private Object login(Map<String, String> p) {
        User u = store.authenticate(str(p, "username"), p.getOrDefault("password", ""));
        return u.toMap(store.displayName(u));
    }

    private Object register(Map<String, String> p) {
        User u = store.register(str(p, "name"), str(p, "email"), str(p, "phone"),
                str(p, "username"), p.getOrDefault("password", ""));
        return u.toMap(store.displayName(u));
    }

    private Object users(String method, String[] seg, Map<String, String> p) {
        if (seg.length == 3 && method.equals("POST") && seg[2].equals("password")) {
            store.changePassword(intOf(p, null, seg[1]), p.getOrDefault("current", ""), p.getOrDefault("next", ""));
            return Map.of("ok", true);
        }
        throw ApiException.notFound("Unknown endpoint.");
    }

    // ----- borrow requests -----

    private Object reservations(String method, String[] seg, Map<String, String> p) {
        if (seg.length == 1 && method.equals("GET")) {
            String status = str(p, "status").isEmpty() ? "all" : str(p, "status");
            Integer member = str(p, "member").isEmpty() ? null : intOf(p, "member", 0);
            return Map.of("reservations", store.reservationViews(status, member));
        }
        if (seg.length == 1 && method.equals("POST")) {
            Reservation r = store.requestBook(intOf(p, "bookId", 0), intOf(p, "memberId", 0));
            return Map.of("id", r.id);
        }
        if (seg.length == 3 && method.equals("POST")) {
            int id = intOf(p, null, seg[1]);
            switch (seg[2]) {
                case "approve": {
                    Loan l = store.approve(id, intOf(p, "days", Store.DEFAULT_LOAN_DAYS));
                    return Map.of("ok", true, "loanId", l.id, "due", l.due.toString());
                }
                case "reject": store.reject(id, str(p, "note")); return Map.of("ok", true);
                case "cancel": {
                    Integer member = str(p, "memberId").isEmpty() ? null : intOf(p, "memberId", 0);
                    store.cancelRequest(id, member);
                    return Map.of("ok", true);
                }
            }
        }
        throw ApiException.notFound("Unknown endpoint.");
    }

    // ----- books -----

    private Object books(String method, String[] seg, Map<String, String> p) {
        if (seg.length == 1) {
            if (method.equals("POST")) {
                Book b = store.addBook(str(p, "title"), str(p, "author"), str(p, "isbn"), str(p, "category"), intOf(p, "copies", 1));
                return b.toMap();
            }
            List<Map<String, Object>> list = new ArrayList<>();
            for (Book b : store.searchBooks(str(p, "q"), str(p, "category"), "1".equals(str(p, "available")))) list.add(b.toMap());
            return Map.of("books", list, "categories", store.categories());
        }
        int id = intOf(p, null, seg[1]);
        if (seg.length == 2 && method.equals("GET")) return store.getBook(id).toMap();
        if (seg.length == 3 && method.equals("POST")) {
            switch (seg[2]) {
                case "update": return store.updateBook(id, str(p, "title"), str(p, "author"), str(p, "isbn"), str(p, "category"), intOf(p, "copies", 1)).toMap();
                case "delete": store.deleteBook(id); return Map.of("ok", true);
            }
        }
        throw ApiException.notFound("Unknown endpoint.");
    }

    // ----- members -----

    private Object members(String method, String[] seg, Map<String, String> p) {
        if (seg.length == 1) {
            if (method.equals("POST")) {
                return store.addMember(str(p, "name"), str(p, "email"), str(p, "phone"), !"0".equals(str(p, "active"))).toMap();
            }
            List<Map<String, Object>> list = new ArrayList<>();
            for (Member m : store.searchMembers(str(p, "q"))) {
                Map<String, Object> row = m.toMap();
                row.put("activeLoans", store.activeLoanCount(m.id));
                list.add(row);
            }
            return Map.of("members", list);
        }
        int id = intOf(p, null, seg[1]);
        if (seg.length == 2 && method.equals("GET")) return store.getMember(id).toMap();
        if (seg.length == 3 && method.equals("POST")) {
            switch (seg[2]) {
                case "update": return store.updateMember(id, str(p, "name"), str(p, "email"), str(p, "phone"), !"0".equals(str(p, "active"))).toMap();
                case "delete": store.deleteMember(id); return Map.of("ok", true);
            }
        }
        throw ApiException.notFound("Unknown endpoint.");
    }

    // ----- loans -----

    private Object loans(String method, String[] seg, Map<String, String> p) {
        if (seg.length == 1 && method.equals("GET")) {
            String status = str(p, "status").isEmpty() ? "all" : str(p, "status");
            Integer member = p.containsKey("member") && !str(p, "member").isEmpty() ? intOf(p, "member", 0) : null;
            Integer book = p.containsKey("book") && !str(p, "book").isEmpty() ? intOf(p, "book", 0) : null;
            return Map.of("loans", store.loanViews(status, member, book), "finePerDay", Store.FINE_PER_DAY);
        }
        if (seg.length == 2 && method.equals("POST")) {
            switch (seg[1]) {
                case "issue": {
                    Loan l = store.issue(intOf(p, "bookId", 0), intOf(p, "memberId", 0), intOf(p, "days", Store.DEFAULT_LOAN_DAYS));
                    return Map.of("id", l.id, "due", l.due.toString());
                }
                case "return": {
                    Loan l = store.returnBook(intOf(p, "loanId", 0));
                    return Map.of("id", l.id, "fine", l.fine, "overdueDays", l.overdueDays(l.returned));
                }
            }
        }
        throw ApiException.notFound("Unknown endpoint.");
    }

    // ----- helpers -----

    private static void requirePost(String method) {
        if (!method.equals("POST")) throw new ApiException(405, "Use POST.");
    }

    private static String str(Map<String, String> p, String key) {
        String v = p.get(key);
        return v == null ? "" : v.trim();
    }

    /** Reads an integer from params[key]; if key is null, parses fallbackText instead. */
    private static int intOf(Map<String, String> p, String key, Object fallback) {
        String raw = key == null ? String.valueOf(fallback) : p.get(key);
        if (raw == null || raw.isBlank()) {
            if (key != null && fallback instanceof Integer i) return i;
            throw ApiException.bad("Missing number: " + key);
        }
        try {
            return Integer.parseInt(raw.trim());
        } catch (NumberFormatException e) {
            throw ApiException.bad("\"" + raw + "\" is not a valid number.");
        }
    }

    private static Map<String, String> parse(String s) {
        Map<String, String> m = new HashMap<>();
        if (s == null || s.isEmpty()) return m;
        for (String pair : s.split("&")) {
            if (pair.isEmpty()) continue;
            int eq = pair.indexOf('=');
            String k = eq < 0 ? pair : pair.substring(0, eq);
            String v = eq < 0 ? "" : pair.substring(eq + 1);
            m.put(URLDecoder.decode(k, StandardCharsets.UTF_8), URLDecoder.decode(v, StandardCharsets.UTF_8));
        }
        return m;
    }
}
