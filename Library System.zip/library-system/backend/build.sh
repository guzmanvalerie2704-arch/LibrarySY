#!/bin/sh
# Compiles the Java backend into ./out  (needs JDK 17 or newer)
cd "$(dirname "$0")" || exit 1
rm -rf out && mkdir -p out
find src -name '*.java' > sources.txt
javac -d out @sources.txt && echo "Build OK" || echo "Build FAILED"
rm -f sources.txt
