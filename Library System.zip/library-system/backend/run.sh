#!/bin/sh
# Starts the Java API on http://127.0.0.1:8080  (usage: ./run.sh [port] [data-folder])
cd "$(dirname "$0")" || exit 1
[ -d out ] || ./build.sh
java -cp out library.Main "${1:-8080}" "${2:-data}"
